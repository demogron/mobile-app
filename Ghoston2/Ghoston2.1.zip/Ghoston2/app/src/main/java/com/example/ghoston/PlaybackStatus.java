package com.example.ghoston;

public enum PlaybackStatus {
    PLAYING,
    PAUSED
}
